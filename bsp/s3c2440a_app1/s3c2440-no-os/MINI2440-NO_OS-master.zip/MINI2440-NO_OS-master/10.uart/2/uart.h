extern void uart_init(void);
extern void putc(unsigned char c);
extern unsigned char getc(void);
