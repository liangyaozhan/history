
#define SERIAL_ECHO

void init_uart(void);
void putc(unsigned char c);
unsigned char getc(void);
