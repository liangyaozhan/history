#include <stdio.h>

extern void asm_strcpy(const char *src, char *dest);

void add(int a, int b);

int Main()
{
	const char *s = "seasons in thre sum";
	char d[32];
	asm_strcpy(s, d);
	printf("source: %s", s);
	printf("destination: %s", d);
	
	return 0;
}
