/*************************************************
Function name: ���ǻ���ʵ���һ��ģ��
Parameter    : ��
Description  : ������ʵ�飬ֱ�ӵ��ø�ģ�弴��  NorFlash�����ǰ��main.c  NorFlash.c NorFlash.h���ص�����û�䡣
Return	     : ��
Argument     : ��
Autor & date : Daniel
**************************************************/
#define	GLOBAL_CLK		1
#include <stdlib.h>
#include <string.h>
#include "def.h"
#include "option.h"
#include "2440addr.h"
#include "2440lib.h"
#include "2440slib.h"
#include "mmu.h"
#include "profile.h"
#include "memtest.h"

U32 SectorNum;
U16 dat;

U8 ID_Status;
 
/********************************************************************************************************
 * Function : int main(void) 
 * Description : ������          
 * Inputs : none.
 * Outputs : None.
 *��ǰ�汾��1.01
 *���ߣ��ɶ���Ƕ
 *���ʱ�䣺2011��5��08��
 *********************************************************************************************************/
int Main(void)
{
	U16 ReadDat[32768];
	U16 i;
	U16 WriteDat[32768];
	S8 InputString[7];
   	S8 *RdString  = "read";
   	S8 *WrString  = "write";
   	S8 *EsString  = "erase"; 
	S8 *String1   = "chip";
	S8 *String2   = "sector";
			
   	//BSP_Init();
   	rGPHCON &= ~(0X0F << 4);
   	rGPHCON |= (0X0A << 4);	
   	PCLK = 50000000;
   	Uart_Init(0, 115200);
   	Uart_Select(0);
   	   				
   	Uart_Printf("*************************************************************\n");
   	Uart_Printf("		 		�ɶ���Ƕ��Ϣ�������޹�˾	     \n\n");
   	Uart_Printf("			   		NoFlash��д����				 \n\n");
   	Uart_Printf("Version: V1.00								   \n");
  	Uart_Printf("***********************************************************\n\n");
	NoFlash_Reset();              //�ȸ�λоƬ
	Software_ID_Entry();			  //��ȡnorflash id��	
   	while(1)
   	{
		NoFlash_Reset();			 //�����ٴθ�λ		
		Uart_Printf("Write data input��write   Read data input��read    Erase  input��erase\n\n");
		Uart_Printf("Select NorFlash Opreation��");
		Uart_GetString(InputString);        
		Uart_Printf("\n");
//-------------------------------------------------------------------------------------------------
		if(!strcmp(WrString,InputString))
		{
			memset(InputString,0,sizeof(InputString));
			Uart_Printf("Note: You must write Sector from 7 to 34!\n");
			Uart_Printf("If you input Sector number from 0 to 6,then you will erase VIVI or UBOOT!\n\n");
			Uart_Printf("Input Program Sector number:");
			SectorNum = Uart_GetIntNum_GJ();
			Uart_Printf("\n\n");
			for(i = 0; i < 32 * 1024;i++)			        //���ݼĴ���			
			{
				WriteDat[i] = i;
			}
			if(SectorNum < 7)
			{
				Uart_Printf("You maybe erase vivi or Uboot,can you do it?y/n.\n");
				Uart_GetString(InputString);
				if(InputString == "y")
				{
					NoFlash_SectorErase(0);					           //0��������
					Delay(500);
					NoFlash_Program_Sector(0,WriteDat,8 * 1024);
					Delay(500);
					NoFlash_SectorErase(8 * 1024);					   //1��������
					Delay(500);	
					NoFlash_Program_Sector(8 * 1024,WriteDat,4 * 1024);
					Delay(500);
					NoFlash_SectorErase((8 + 4) * 1024);			   //2��������
					Delay(500);	
					NoFlash_Program_Sector(((8 + 4) * 1024),WriteDat,4 * 1024);
					Delay(500);
					NoFlash_SectorErase((8 + 4 + 4) * 1024);		   //3��������
					Delay(500);	
					NoFlash_Program_Sector(((8 + 4 + 4) * 1024),WriteDat,16 * 1024);
					Delay(500);
					for(i = 4;i < 7;i++)
					{
						NoFlash_SectorErase((i - 3) * 1024 * 32);
						Delay(500);	
						NoFlash_Program_Sector(((i - 3) * 1024 * 32),WriteDat,1024 * 32);
						Delay(500);						
					}
				}
			}
			else if((SectorNum >= 7) && (SectorNum <= 34))
			{
				NoFlash_SectorErase((SectorNum - 3) * 1024 * 32);
				Delay(500);	
				NoFlash_Program_Sector(((SectorNum - 3) * 1024 * 32),WriteDat,1024 * 32);
				Delay(500);
				Uart_Printf("Sector %d Program Sucess,start address 0x%x end 0x%x!\n",
				            SectorNum,((SectorNum - 3) * 1024 * 32),((SectorNum - 3) * 1024 * 32 + 1024*32 - 1));				
			}
			else
			{
				Uart_Printf("input sector error!\n");
			}																										
			Uart_Printf("\n");
			Uart_Printf("************************************************************************\n\n");
		}
//--------------------------------------------------------------------------------------------------				
		if(!strcmp(RdString,InputString))
		{
			memset(InputString,0,sizeof(InputString));
			Uart_Printf("Input Read Sector number:");
			SectorNum = Uart_GetIntNum_GJ();
			Uart_Printf("\n\n");
			memset(ReadDat,0,sizeof(ReadDat));
			if(SectorNum == 0) 
			{
				NoFlash_Read_Sector(0,ReadDat,1024);
				Uart_Printf("Read  Sector %d Sucess,Start address 0x0000 end 0x1FFF!\n",SectorNum);
				for(i = 0;i < 1024; i++)
					Uart_Printf("0x%x  ",ReadDat[i]);	
			}
			else if(SectorNum == 1)
			{
				NoFlash_Read_Sector(8 * 1024,ReadDat,1024);
				Uart_Printf("Read  Sector %d Sucess,Start address 0x2000 end 0x2FFF!\n",SectorNum);
				for(i = 0;i < 1024; i++)
					Uart_Printf("0x%x  ",ReadDat[i]);
			}
			else if(SectorNum == 2)
			{
				NoFlash_Read_Sector((8 + 4) * 1024,ReadDat,1024);
				Uart_Printf("Read  Sector %d Sucess,Start address 0x3000 end 0x3FFF!\n",SectorNum);
				for(i = 0;i < 1024; i++)
					Uart_Printf("0x%x  ",ReadDat[i]);
			}
			else if(SectorNum == 3)
			{
				NoFlash_Read_Sector((8 + 4 + 4) * 1024,ReadDat,1024);
				Uart_Printf("Read  Sector %d Sucess,Start address 0x4000 end 0x7FFF!\n",SectorNum);
				for(i = 0;i < 1024; i++)
					Uart_Printf("0x%x  ",ReadDat[i]);
			}
			else if((SectorNum > 3) && (SectorNum <= 34))
			{
				NoFlash_Read_Sector(((SectorNum - 3) * 1024 * 32),ReadDat,1024);
				Uart_Printf("Read Sector 0x%d Sucess,Start address 0x%x end 0x%x!\n",
				            SectorNum,((SectorNum - 3) * 1024 * 32),((SectorNum - 3) * 1024 * 32) + 1024 * 32 - 1);
				for(i = 0;i < 1024; i++)
				{
					Uart_Printf("0x%x  ",ReadDat[i]);
				}
			}
			else 
			{
				Uart_Printf("input sector error!\n");
			}				
			Uart_Printf("\n\n");
		}						
//--------------------------------------------------------------------------------------------------
		if(!strcmp(EsString,InputString))
		{
			memset(InputString,0,sizeof(InputString));
			Uart_Printf("erase chip or sector?");
			Uart_GetString(InputString);
			if(!strcmp(String1,InputString))
			{
				memset(InputString,0,sizeof(InputString));
			    NoFlash_ChipErase();
				Delay(6000);
			}
			if(!strcmp(String2,InputString))
			{
				memset(InputString,0,sizeof(InputString));
				Uart_Printf("Note: You must  write Sector from 7 to 34!\n");
				Uart_Printf("If you input Sector number from 0 to 6,then you will erase VIVI or UBOOT!\n");
				Uart_Printf("Input Erase Secter number:");
				SectorNum = Uart_GetIntNum_GJ();
				if(SectorNum < 7)
				{
					Uart_Printf("You maybe erase vivi or Uboot,can you do it?y/n.\n");
					Uart_GetString(InputString);
					if(InputString == "y")			//����vivi
					{
						NoFlash_SectorErase(0);
						Delay(500);		
						NoFlash_SectorErase(8 * 1024);
						Delay(500);			
						NoFlash_SectorErase((8 + 4) * 1024);
						Delay(500);	
						NoFlash_SectorErase((8 + 4 + 4) * 1024);
						Delay(500);	
						for(i = 4;i < 7;i++)
						{
							NoFlash_SectorErase((i - 3) * 1024 * 32);
							Delay(500);							
						}
					}
				}
				else
				{
					Uart_Printf("\n\n");
					NoFlash_SectorErase((SectorNum - 3) * 1024 * 32);
					Delay(500);
					Uart_Printf("\n");					
				}
			}
			Uart_Printf("************************************************************************\n\n");
		}
				
   	}	   	   	
}	
	
