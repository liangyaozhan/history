/****************************************************************
 NAME: MAIN.h
 DESC: 
 HISTORY:
 Mar.29.2002:purnnamu: created first
 ****************************************************************/
 
#ifndef __MAIN_H__
#define __MAIN_H__

int  StartI2C(unsigned char sla);
#endif /*__MAIN_H__*/
