/*********************************************************************************************************
*
*                              			S3C2440 NorFlash��������
*
*                                            SAMSUNG S3C2440 
*                                                 on the
*                                        mini2440 Evaluation Board
										 NorFlash�ͺţ�(S29AL016J70TFI020)
*
* Filename      : NorFlash.h
* Version       : V1.00
* Programmer(s) : Robert.liao
* LegalCopyright: �ɶ���Ƕ��Ϣ�������޹�˾
*********************************************************************************************************/
#ifndef __NOFLASH_H__
#define __NOFLASH_H__

#define  DEBUG

#define  MAKERID								0x01
#define  TOPDEVID								0x2249
#define  BOTTOMDEVID							0x22C4

#define  IDTURE									0x01
#define	 IDFALSE							    0x00

#define  Oper_Finish							1
#define  Oper_NoFinish							0

#define  EraseSucess							1
#define  EraseUnSucess							0

#define  BaseAddr								0x00000000		 			//NorFlash�Ļ���ַ����Ϊ0

#define  FlashAddr16(BaseAddr, Offset) 			(volatile U16 *)((BaseAddr)+(Offset))

U8	 	NoFlash_Toggle							(U32 Addr,U32 offset);
void 	NoFlash_Write_Byte						(U32 offset,U32 Dat);
void 	NoFlash_Program_Sector					(U32 PA,U16 *PD,U32 Size);
void 	NoFlash_Read_Sector						(U32 PA,U16 *PD,U32 Size);
void 	NoFlash_SectorErase						(U32 SA);
U16 	NoFlash_Read_Byte						(U32 offset);
void 	NoFlash_Reset							(void);
void 	Software_ID_Entry						(void);
void 	Software_ID_Exit						(void);
void 	NoFlash_ChipErase						(void);

#endif
