/*********************************************
  NAME: memtest.h
  DESC: 
  HISTORY:
  03.27.2002:purnnamu: first release
 *********************************************/


#ifndef __memtest_h__
#define __memtest_h__

void MemoryTest(void);

#endif  //__memtest_h__
