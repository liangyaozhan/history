/*************************************************
Function name: ���ǻ���ʵ���һ��ģ��
Parameter    : ��
Description  : ������ʵ�飬ֱ�ӵ��ø�ģ�弴��
Return	     : ��
Argument     : ��
Autor & date : Daniel
**************************************************/
#define	GLOBAL_CLK		1
#include <stdlib.h>
#include <string.h>
#include "def.h"
#include "option.h"
#include "2440addr.h"
#include "2440lib.h"
#include "2440slib.h"
#include "mmu.h"
#include "profile.h"
#include "memtest.h"


#define ADC_FREQ 2500000
//#define ADC_FREQ   1250000


volatile U32 preScaler;

void adc_init(void);
int ReadAdc(int channel);
static void cal_cpu_bus_clk(void);
void Set_Clk(void);
void beep_init(void);
void beep_run(void);
/*************************************************
Function name: delay
Parameter    : times
Description	 : ��ʱ����
Return		 : void
Argument     : void
Autor & date : Daniel
**************************************************/
void delay(int times)
{
    int i,j;
    for(i=0;i<times;i++)
       for(j=0;j<400;j++);
}
/*************************************************
Function name: Main
Parameter    : void
Description	 : �����ܺ���
Return		 : void
Argument     : void
Autor & date : Daniel
**************************************************/
void Main(void)
{	
    int a0=0,tmp;
    int Scom=0;
    Set_Clk();
    beep_init();
    
    rGPHCON &= ~(0X0F << 4);
    rGPHCON |= (0X0A << 4);
    
    Uart_Init(0,115200);
    Uart_Select(Scom);
    Uart_Printf("\nHello World!\n");
    
    adc_init();
    //tmp=a0;
    while(1)
    {
        a0=ReadAdc(0);
      //  if(a0 != tmp)
          Uart_Printf( "AIN0: %04d\n", a0);
      //  tmp=a0;  
		delay(1000) ;
	}

}	

/*************************************************
Function name: adc_init()
Parameter    : int channel
Description	 : adc��ʼ��
Return		 : void
Argument     : void
Autor & date : Daniel
**************************************************/ 
void adc_init(void)
{
	int channel=0; //AIN0����Ӧ��������W1�ɵ�����
	
	preScaler = ADC_FREQ;
	Uart_Printf("ADC conv,freq. = %dHz\n",preScaler);
	preScaler = 50000000/ADC_FREQ - 1; //PCLK=50M
	
	Uart_Printf("PRSCVL=PCLK/ADC_FREQ - 1=%d\n",preScaler);
	
	/*ADת��Ƶ�����ã����Ƶ��Ϊ2.5MHz*/
	rADCCON = (1<<14)|(preScaler<<6)|(channel<<3);	//setup channel
//	delay(1000);		

}
    
/*************************************************
Function name: ReadAdc(int channel)
Parameter    : int channel
Description	 : ��ȡAD ת�����ֵ
Return		 : int
Argument     : void
Autor & date : Daniel
**************************************************/    
int ReadAdc(int channel)
{

	/*����ADת��*/
	rADCCON |= 0x01; //start ADC
	
	
	while(rADCCON & 0x1);	//check if Enable_start is low
	
    while(!(rADCCON & 0x8000));	//check if EC(End of Conversion) flag is high
    

    return ( (int)rADCDAT0 & 0x3ff );
} 
/*************************************************
Function name: Set_Clk()
Parameter    : void
Description	 : ����CPU��ʱ��Ƶ��
Return		 : void
Argument     : void
Autor & date : Daniel
**************************************************/
void Set_Clk(void)
{
	int i;
	U8 key;
	U32 mpll_val = 0 ;
	i = 2 ;	             //don't use 100M!
		                 //boot_params.cpu_clk.val = 3;
	switch ( i ) {
	case 0:	//200
		key = 12;
		mpll_val = (92<<12)|(4<<4)|(1);
		break;
	case 1:	//300
		key = 13;
		mpll_val = (67<<12)|(1<<4)|(1);
		break;
	case 2:	//400
		key = 14;
		mpll_val = (92<<12)|(1<<4)|(1);
		break;
	case 3:	//440!!!
		key = 14;
		mpll_val = (102<<12)|(1<<4)|(1);
		break;
	default:
		key = 14;
		mpll_val = (92<<12)|(1<<4)|(1);
		break;
	}
	
	//init FCLK=400M, so change MPLL first
	ChangeMPllValue((mpll_val>>12)&0xff, (mpll_val>>4)&0x3f, mpll_val&3);   //set the register--rMPLLCON
	ChangeClockDivider(key, 12);    //the result of rCLKDIVN [0:1:0:1] 3-0 bit
	cal_cpu_bus_clk();    //HCLK=100M   PCLK=50M
}
/*************************************************
Function name: cal_cpu_bus_clk
Parameter    : void
Description	 : ����PCLK\HCLK\FCLK��Ƶ��
Return		 : void
Argument     : void
Autor & date : Daniel
**************************************************/
static void cal_cpu_bus_clk(void)
{
	static U32 cpu_freq;
    static U32 UPLL;
	
	U32 val;
	U8 m, p, s;
	
	val = rMPLLCON;
	m = (val>>12)&0xff;
	p = (val>>4)&0x3f;
	s = val&3;

	//(m+8)*FIN*2 ��Ҫ����32λ��!
	FCLK = ((m+8)*(FIN/100)*2)/((p+2)*(1<<s))*100;     //FCLK=400M  FIN=12000000
	
	val = rCLKDIVN;
	m = (val>>1)&3;
	p = val&1;	
	val = rCAMDIVN;
	s = val>>8;
	
	switch (m) {
	case 0:
		HCLK = FCLK;
		break;
	case 1:
		HCLK = FCLK>>1;
		break;
	case 2:
		if(s&2)
			HCLK = FCLK>>3;
		else
			HCLK = FCLK>>2;
		break;
	case 3:
		if(s&1)
			HCLK = FCLK/6;
		else
			HCLK = FCLK/3;
		break;
	}
	
	if(p)
		PCLK = HCLK>>1;
	else
		PCLK = HCLK;
	
	if(s&0x10)
		cpu_freq = HCLK;
	else
		cpu_freq = FCLK;
		
	val = rUPLLCON;
	m = (val>>12)&0xff;
	p = (val>>4)&0x3f;
	s = val&3;
	UPLL = ((m+8)*FIN)/((p+2)*(1<<s));
	UCLK = (rCLKDIVN&8)?(UPLL>>1):UPLL;
}

/*************************************************
Function name: beep_init()
Parameter    : void
Description	 : ��ʼ��������
Return		 : void
Argument     : void
Autor & date : Daniel
**************************************************/
void beep_init(void)
{
    rGPBCON &= ~(0x3<<0);
    rGPBCON |=  (0x1<<0);
}
/*************************************************
Function name: beep_run()
Parameter    : void
Description	 : ���з�����
Return		 : void
Argument     : void
Autor & date : Daniel
**************************************************/
void beep_run(void)
{
    rGPBDAT |= (0x1<<0);
    delay(5000);
    rGPBDAT &= (0x0<<0);
    delay(5000);
}
