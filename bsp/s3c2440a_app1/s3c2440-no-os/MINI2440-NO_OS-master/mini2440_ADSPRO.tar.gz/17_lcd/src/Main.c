/*************************************************
Function name: ���ǻ���ʵ���һ��ģ��
Parameter    : ��
Description  : ������ʵ�飬ֱ�ӵ��ø�ģ�弴��
Return	     : ��
Argument     : ��
Autor & date : Daniel
**************************************************/
#define	GLOBAL_CLK		1
#include <stdlib.h>
#include <string.h>
#include "def.h"
#include "option.h"
#include "2440addr.h"
#include "2440lib.h"
#include "2440slib.h"
#include "mmu.h"
#include "profile.h"
#include "memtest.h"



#define LCD_N35 //NEC 256Kɫ240*320/3.5Ӣ��TFT���Һ����,ÿһ��ˮƽ���ϰ���240�����ص㣬����320����������

#if defined(LCD_N35)

#define LCD_WIDTH 320
#define LCD_HEIGHT 240
#define LCD_PIXCLOCK 4

#define LCD_RIGHT_MARGIN 0x44//68//1
#define LCD_LEFT_MARGIN 0x04//2//2
#define LCD_HSYNC_LEN 1

#define LCD_UPPER_MARGIN 10//10//4
#define LCD_LOWER_MARGIN 4//18//18
#define LCD_VSYNC_LEN 1

#endif

void TFT_LCD_Test(void);

#define LCD_XSIZE  LCD_WIDTH
#define LCD_YSIZE  LCD_HEIGHT
#define SCR_XSIZE  LCD_WIDTH
#define SCR_YSIZE  LCD_HEIGHT

volatile static unsigned short LCD_BUFFER[SCR_YSIZE][SCR_XSIZE];  //����320�У�240�е����飬���ڴ����ʾ����

extern unsigned char sunflower_240x320[];
extern unsigned char canglaoshi_320x240[];
extern unsigned char sunflower_1[];
extern unsigned char sunflower_4[];
extern unsigned char sunflower_8[];
extern unsigned char sunflower_16[];
extern unsigned char sunflower_24[];
extern unsigned char sunflower_124[];
extern unsigned char canglaoshi[];
extern unsigned char canglaoshi2[];
extern unsigned char fuck[];
#define ADC_FREQ 2500000
//#define ADC_FREQ   1250000

volatile U32 preScaler;




static void cal_cpu_bus_clk(void);
void Set_Clk(void);

/*************************************************
Function name: delay
Parameter    : times
Description	 : ��ʱ����
Return		 : void
Argument     : void
Autor & date : Daniel
**************************************************/
void delay(int times)
{
    int i,j;
    for(i=0;i<times;i++)
       for(j=0;j<400;j++);
}
/*************************************************
Function name: Main
Parameter    : void
Description	 : �����ܺ���
Return		 : void
Argument     : void
Autor & date : Daniel
**************************************************/
int Main(void)
{	
   
    int Scom=0;
    MMU_Init();
    Set_Clk();
 	//SERAL  GPIO
 	rGPHCON &= ~(0X0F << 4);
 	rGPHCON |= (0X0A << 4);
 	
 	
    Uart_Init(0,115200);
    Uart_Select(Scom);
    //Uart_Printf("\nHello World!\n");
    
    TFT_LCD_Test();
    
	return 0;

}	


/*************************************************
Function name: Pait_Bmp
Parameter    : void
Description	 : ��LCD��Ļ��ָ������㻭һ��ָ����С��ͼƬ
Return		 : void
Argument     : int x0,int y0,int h,int l,const unsigned char *bmp
Autor & date : Daniel
**************************************************/
static void Pait_Bmp(int x0,int y0,int h,int l,const unsigned char *bmp)
{
	int x,y;
	U32 c;
	int p = 0;
	
    for( y = 0 ; y < l ; y++ )
    {
    	for( x = 0 ; x < h ; x++ )
    	{
    		c = bmp[p+1] | (bmp[p]<<8) ;

			if ( ( (x0+x) < SCR_XSIZE) && ( (y0+y) < SCR_YSIZE) )
				LCD_BUFFER[y0+y][x0+x] = c ;

    		p = p + 2 ;
    	}
    }
}


/*************************************************
Function name: Lcd_ClearScr
Parameter    : void
Description	 : 240��320 TFT LCDȫ������ض���ɫ��Ԫ������
Return		 : void
Argument     : U16
Autor & date : Daniel
**************************************************/
static void Lcd_ClearScr( U16 c)
{
	unsigned int x,y ;
		
    for( y = 0 ; y < SCR_YSIZE ; y++ )
    {
    	for( x = 0 ; x < SCR_XSIZE ; x++ )
    	{
			LCD_BUFFER[y][x] = c ;
    	}
    }
}


/*************************************************
Function name: Lcd_EnvidOnOff
Parameter    : void
Description	 : LCD��Ƶ�Ϳ����ź��������ֹͣ��1������Ƶ��ʾ�������
Return		 : void
Argument     : int
Autor & date : Daniel
**************************************************/
static void Lcd_EnvidOnOff(int onoff)
{
    if(onoff==1)
	rLCDCON1|=1; // ENVID=ON
    else
	rLCDCON1 =rLCDCON1 & 0x3fffe; // ENVID Off
}


/*************************************************
Function name: Lcd_Port_Init
Parameter    : void
Description	 : 240*320 TFT LCD���ݺͿ��ƶ˿ڳ�ʼ��
Return		 : void
Argument     : void
Autor & date : Daniel
**************************************************/
static void Lcd_Port_Init( void )
{
    rGPCUP=0xffffffff; // Disable Pull-up register
    rGPCCON=0xaaaa02a8; //Initialize VD[7:0],VM,VFRAME,VLINE,VCLK

    rGPDUP=0xffffffff; // Disable Pull-up register
    rGPDCON=0xaaaaaaaa; //Initialize VD[15:8]
}


/*************************************************
Function name: LCD_Init
Parameter    : void
Description	 : 240��320 TFT LCD����ģ���ʼ��
Return		 : void
Argument     : void
Autor & date : Daniel
**************************************************/
static void LCD_Init(void)
{
#define	M5D(n)	((n)&0x1fffff)
#define LCD_ADDR ((U32)LCD_BUFFER)

	/*bit[17:8](4:CLKVAL);bit[6:5](11:TFT LCD panel);bit[4:1](1100:16 bpp for TFT)*/
	rLCDCON1 = (LCD_PIXCLOCK << 8) | (3 <<  5) | (12 << 1) ;
	
	/*bit[31:24](1:VBPD);bit[23:14](320-1:����);bit[13:6](5:VFPD);bit[5:0](1:VSPW)*/
   	rLCDCON2 = (LCD_UPPER_MARGIN << 24) | ((LCD_HEIGHT - 1) << 14) | (LCD_LOWER_MARGIN << 6) | (LCD_VSYNC_LEN << 0);
   	
   	/*bit[25:19](36:HBPD);bit[18:8](240-1:����);bit[7:0](19:HFPD)*/
   	rLCDCON3 = (LCD_RIGHT_MARGIN << 19) | ((LCD_WIDTH  - 1) <<  8) | (LCD_LEFT_MARGIN << 0);
   	
   	/*bit[15:8](13:MVAL,ֻ�е�LCDCON1 bit[7]MMODE=1����Ч);bit[7:0](5:HSPW)*/
   	rLCDCON4 =  (LCD_HSYNC_LEN << 0);

#if !defined(LCD_CON5)
	/*bit[11](5:6:5 Format);bit[9](VLINE/HSYNC polarity inverted);bit[8](VFRAME/VSYNC inverted)
	  bit[3](Enalbe PWERN signal),bit[1](half-word swap control bit)*/
#    define LCD_CON5 ((1<<11) | (1 << 9) | (1 << 8) | (1 << 3) | (1 << 1))
#endif
    rLCDCON5   =  LCD_CON5;

	/*
	LCDBANK: ��Ƶ֡�������ڴ��ַ30-22λ
	LCDBASEU: ��Ƶ֡�������Ŀ�ʼ��ַ21-1λ
	LCDBASEL: ��Ƶ֡�������Ľ�����ַ21-1λ
	*/
	/*bit[29:21]:LCDBANK,bit[20:0]:LCDBASEU*/
    rLCDSADDR1 = ((LCD_ADDR >> 22) << 21) | ((M5D(LCD_ADDR >> 1)) <<  0);
    
    /*bit[20:0]:LCDBASEL*/
    rLCDSADDR2 = M5D((LCD_ADDR + LCD_WIDTH * LCD_HEIGHT * 2) >> 1);
    
    
    /*PAGEWIDTH:������Ļһ�е��ֽ����������ʹ��������Ļ������Ϊʵ����Ļ�����ֽ���
	  OFFSIZE:������Ļ���ƫ�Ƶ��ֽ����������ʹ��������Ļ������Ϊ0
	*/
	/*bit[21:11]:OFFSIZE; bit[10:0]:PAGEWIDTH*/
    rLCDSADDR3 = LCD_WIDTH;        

	/*�����ж�*/
    rLCDINTMSK |= 3;
  	rTCONSEL   &= (~7);
 
	/*disable��ɫ��*/
   	rTPAL     = 0x0;
   	
   	/*��ֹLPC3600/LCC3600ģʽ*/
   	rTCONSEL &= ~((1<<4) | 1);

    
}

/*************************************************
Function name: TFT_LCD_Testt
Parameter    : void
Description	 : mini2440 LCD����
Return		 : void
Argument     : void
Autor & date : Daniel
**************************************************/
void TFT_LCD_Test(void)
{
	U32 i;
 
	Uart_Printf("\nTest TFT LCD 240x320!\n");  

	
    Lcd_Port_Init();
    LCD_Init();
    Lcd_EnvidOnOff(1);		//turn on vedio

	Uart_Printf("LCD clear screen!\n");
	
	/*��(255:0:0);��(0:255:0);��(0:0:255);��(0:0:0);��(255,255,255)*/
	
	/*����Ļ����ʾ����ɫ*/
	
		Lcd_ClearScr( (0x00<<11) | (0x00<<5) | (0x00)  )  ;		//clear screen black
		delay(10000);
		
		Lcd_ClearScr((0x1f<<11) | (0x00<<5) | (0x00));			//red
		delay(10000);
		Lcd_ClearScr((0x00<<11) | (0x3f<<5) | (0x00));			//green
		delay(10000);
		Lcd_ClearScr((0x00<<11) | (0x00<<5) | (0x1f));			//blue
		delay(10000);

		Lcd_ClearScr( (0x1f<<11) | (0x3f<<5) | (0x1f)  )  ;		//clear screen white
		delay(10000);
	
	
	
    
	Lcd_ClearScr(0xffff);		//fill all screen with some color
	
	/*��ʾһ��ͼƬ����Ļ��*/
	
	Pait_Bmp(0, 0, 320, 240, canglaoshi);
 
   	Uart_Printf( "LCD clear screen is finished!\n" );

  //  Lcd_EnvidOnOff(0);		//turn off vedio
}
   

/*************************************************
Function name: Set_Clk()
Parameter    : void
Description	 : ����CPU��ʱ��Ƶ��
Return		 : void
Argument     : void
Autor & date : Daniel
**************************************************/
void Set_Clk(void)
{
	int i;
	U8 key;
	U32 mpll_val = 0 ;
	i = 2 ;	             //don't use 100M!
		                 //boot_params.cpu_clk.val = 3;
	switch ( i ) {
	case 0:	//200
		key = 12;
		mpll_val = (92<<12)|(4<<4)|(1);
		break;
	case 1:	//300
		key = 13;
		mpll_val = (67<<12)|(1<<4)|(1);
		break;
	case 2:	//400
		key = 14;
		mpll_val = (92<<12)|(1<<4)|(1);
		break;
	case 3:	//440!!!
		key = 14;
		mpll_val = (102<<12)|(1<<4)|(1);
		break;
	default:
		key = 14;
		mpll_val = (92<<12)|(1<<4)|(1);
		break;
	}
	
	//init FCLK=400M, so change MPLL first
	ChangeMPllValue((mpll_val>>12)&0xff, (mpll_val>>4)&0x3f, mpll_val&3);   //set the register--rMPLLCON
	ChangeClockDivider(key, 12);    //the result of rCLKDIVN [0:1:0:1] 3-0 bit
	cal_cpu_bus_clk();    //HCLK=100M   PCLK=50M
}
/*************************************************
Function name: cal_cpu_bus_clk
Parameter    : void
Description	 : ����PCLK\HCLK\FCLK��Ƶ��
Return		 : void
Argument     : void
Autor & date : Daniel
**************************************************/
static void cal_cpu_bus_clk(void)
{
	static U32 cpu_freq;
    static U32 UPLL;
	
	U32 val;
	U8 m, p, s;
	
	val = rMPLLCON;
	m = (val>>12)&0xff;
	p = (val>>4)&0x3f;
	s = val&3;

	//(m+8)*FIN*2 ��Ҫ����32λ��!
	FCLK = ((m+8)*(FIN/100)*2)/((p+2)*(1<<s))*100;     //FCLK=400M  FIN=12000000
	
	val = rCLKDIVN;
	m = (val>>1)&3;
	p = val&1;	
	val = rCAMDIVN;
	s = val>>8;
	
	switch (m) {
	case 0:
		HCLK = FCLK;
		break;
	case 1:
		HCLK = FCLK>>1;
		break;
	case 2:
		if(s&2)
			HCLK = FCLK>>3;
		else
			HCLK = FCLK>>2;
		break;
	case 3:
		if(s&1)
			HCLK = FCLK/6;
		else
			HCLK = FCLK/3;
		break;
	}
	
	if(p)
		PCLK = HCLK>>1;
	else
		PCLK = HCLK;
	
	if(s&0x10)
		cpu_freq = HCLK;
	else
		cpu_freq = FCLK;
		
	val = rUPLLCON;
	m = (val>>12)&0xff;
	p = (val>>4)&0x3f;
	s = val&3;
	UPLL = ((m+8)*FIN)/((p+2)*(1<<s));
	UCLK = (rCLKDIVN&8)?(UPLL>>1):UPLL;
	//Uart_Printf("\nFCLK:%dMHz,HCLK:%dMHz,PCLK=%dMHZ\n",FCLK/1000/1000,HCLK/1000/1000,PCLK/1000/1000);
}
