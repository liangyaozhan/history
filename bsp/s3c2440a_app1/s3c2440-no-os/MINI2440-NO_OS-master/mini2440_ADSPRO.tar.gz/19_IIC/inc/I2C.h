/*********************************************************************************************************
*
*                                        GQ2440 I2C��������
*
*                                            SAMSUNG S3C2440 
*                                                 on the
*                                        GQ2440 Evaluation Board
*
* Filename      : I2C.h
* Version       : V1.00
* Programmer(s) : Robert.liao
* LegalCopyright: �ɶ���Ƕ��Ϣ�������޹�˾
*********************************************************************************************************/
#ifndef __I2C_H__
#define __I2C_H__

#include "def.h"

extern U8 bArray[256];
extern U8 WrStr[256];

#define    I2CWrSlaAddr		    							0x00
#define    I2CWrMemAddr										0x01
#define    I2CSlaRdAddr										0x02
#define    I2CWrData										0x03
#define    I2CRdData										0x04
#define    I2CStop											0x05
#define    I2CPending										0x06

#define    I2CDisable										0x00
#define    I2CEnable										0x01
//===============================================================================================
//I2C�Ĵ�������
//===============================================================================================

//IICCON���ƼĴ������ݶ���
#define IICBusAckEn											 (1 << 7)
#define IICBusAckDis										 (0 << 7)

#define TxClkSelPclk512										 (1 << 6)
#define TxClkSelPclk16										 (0 << 6)

#define TxRxIntEn											 (1 << 5)
#define TxRxIntDis											 (0 << 5)

#define TxRxIntPend											 (1 << 4)
#define TxRxIntNoPend									    ~(1 << 4)

#define TransClkVal 										 0x07	   //Լ400kbit/s
//IICSTAT���ƼĴ������ݶ���
#define SlaveRecMode										 0x00
#define SlaveSendMode										 0x01
#define MasterRecMode										 0x02
#define MasterSendMode										 0x03

#define IICStop												 (0 << 5)
#define IICDataTrans										 (1 << 5)

#define IICDataDis									         (0 << 4)
#define IICDataEn										     (1 << 4)

#define ArbitateSucess									     (0 << 3)
#define ArbitateUnsucess									 (1 << 3)

#define	ClearStatFlag										 (0 << 2)  //��⵽��ʼ��ֹͣ����ʱ����λ��0
#define MachSlaveAddr										 (1 << 2)

#define CheckStartStop										 (0 << 1)
#define RecSlaAddr0									         (1 << 1)

#define IICRecAck											 (0 << 0)
#define IICRecNoAck											 (1 << 0)

//rIICLC���ƼĴ������ݶ���
#define IICFilterDis									     (0 << 2)
#define IICFilterEn											 (1 << 2)

#define SDAOutDelay0										 0x00
#define SDAOutDelay5										 0x01
#define SDAOutDelay10										 0x02
#define SDAOutDelay15										 0x03 

void I2C_Write			(U8 SlaAddr,U16 MemAddr,U8 *MemDat,U8 DatNum);
void I2C_Read			(U8 SlaAddr,U16 MemAddr,U8 *MemDat,U16 DatNum);
void ASCIIToHex			(U8 Len,U8 *WriteStr);

#endif



