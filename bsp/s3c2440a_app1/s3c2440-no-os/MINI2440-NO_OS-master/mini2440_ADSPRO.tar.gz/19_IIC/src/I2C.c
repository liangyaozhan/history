/*********************************************************************************************************
*
*                                        GQ2440 USB�ӻ���������
*
*                                            SAMSUNG S3C2440 
*                                                 on the
*                                        GQ2440 Evaluation Board
*
* Filename      : I2C.c
* Version       : V1.00
* Programmer(s) : Robert.liao
* LegalCopyright: �ɶ���Ƕ��Ϣ�������޹�˾
*********************************************************************************************************/

/*********************************************************************************************************
*                                             INCLUDE FILES
**********************************************************************************************************/
#include <stdlib.h>
#include <string.h>
#include "def.h"
#include "option.h"
#include "2440addr.h"
#include "2440lib.h"
#include "2440slib.h"
#include "mmu.h"
#include "profile.h"
#include "memtest.h"
//#include "Init.h"
#include "I2C.h"
//#include "Delay.h"

U8 bArray[256] = {0};		
U8 WrStr[256] =  {0}; 
/***********************************/
U8	IIC_Ack;//add by kangear
		
/********************************************************************************************************
 * Function : void I2C_Write(U8 SlaveAddr,U16 MemAddr,U8 Dat) 
 * Description : S3C2440ͨ��I2C����������AT24C08д������           
 * Inputs : SlaAddr���ӻ���ַ��MemAddr����Ԫ��ַ��MemDat�����ݣ�DatNumҪд�����ݵĸ���.
 * Outputs : None.
 *��ǰ�汾��1.01
 *���ߣ��ɶ���Ƕ
 *���ʱ�䣺2011��5��10��
 *********************************************************************************************************/

void I2C_Write(U8 SlaAddr,U16 MemAddr,U8 *MemDat,U8 DatNum)
{
	U8 i;
	U8 HighAddr;
	U8 LowAddr;
	HighAddr = (U8)((MemAddr & 0xff00) >> 8);
	LowAddr  = (U8)(MemAddr & 0x00ff);
	IIC_Ack = 0;
	 
	rIICSTAT = (MasterSendMode << 6) | IICDataTrans | IICDataEn; 
	rIICDS   = SlaAddr;    										 
	rIICCON &= TxRxIntNoPend;				 					 
	while(IIC_Ack == 0);						
	IIC_Ack = 0;												
			
	rIICDS = HighAddr;											
	rIICDS = LowAddr;										
	rIICCON &= TxRxIntNoPend;			   	
	while(IIC_Ack == 0); 										 
	IIC_Ack = 0;		    									

	for(i = 0; i < DatNum; i++)		  							
	{
		rIICDS  = *MemDat;			  							 
		rIICCON &= TxRxIntNoPend;
		while(IIC_Ack == 0);    								
		IIC_Ack = 0;		    								
		MemDat++;												
	}

	rIICSTAT = (MasterSendMode << 6) | IICStop | IICDataEn; 		
	rIICCON  = IICBusAckEn | TxRxIntEn | TransClkVal; 		
	Delay(500);					  							
}

/********************************************************************************************************
 * Function : void I2C_Read(U8 SlaveAddr,U16 MemAddr,U8 *Dat) 
 * Description : S3C2440ͨ��I2C�����������AT24C08�ж�ȡ����           
 * Inputs : SlaAddr���ӻ���ַ��MemAddr����Ԫ��ַ��MemDat�����ݣ�DatNumҪ��ȡ���ݵĸ���.
 * Outputs : None.
 *��ǰ�汾��1.01
 *���ߣ��ɶ���Ƕ
 *���ʱ�䣺2011��5��10��
 *********************************************************************************************************/

void I2C_Read(U8 SlaAddr,U16 MemAddr,U8 *MemDat,U16 DatNum)
{
	U16 i;
	U8 HighAddr;
	U8 LowAddr;
	HighAddr = (U8)((MemAddr & 0xff00) >> 8);
	LowAddr  = (U8)(MemAddr & 0x00ff);

	IIC_Ack = 0;					 					
	rIICSTAT = (MasterSendMode << 6) | IICDataTrans | IICDataEn; 
	rIICDS   = SlaAddr;    							
	rIICCON &= TxRxIntNoPend;						
					 		
	while(IIC_Ack == 0);								
	IIC_Ack = 0;									
			
	rIICDS = HighAddr;										
	rIICDS = LowAddr;
	rIICCON &= TxRxIntNoPend;			   			
	while(IIC_Ack == 0); 							
	IIC_Ack = 0;		    						

	rIICSTAT = (MasterRecMode << 6) | IICDataTrans | IICDataEn; 				
	rIICDS   = SlaAddr; 										
	rIICCON &= TxRxIntNoPend;				   		
	while(IIC_Ack == 0); 							
	IIC_Ack = 0;
			
	for(i = 0; i < (DatNum - 1); i++)			  		
	{					 
		*MemDat = rIICDS;			     		       								
		Delay(500);							     	  			
		rIICCON &= TxRxIntNoPend;
		while(IIC_Ack == 0); 						   	
		IIC_Ack = 0;
		*MemDat = rIICDS;			         		   	
		MemDat++; 
	}

	*MemDat = rIICDS;			     		     		
	rIICCON = IICBusAckDis | TxRxIntEn | TransClkVal;										
	Delay(500);							     	  			
	*MemDat = rIICDS;			         		  		
	
	rIICSTAT = (MasterRecMode << 6) | IICStop | IICDataEn; 
	rIICCON  = IICBusAckEn | TxRxIntEn | TransClkVal;	   							
	Delay(500);					
		
}

/********************************************************************************************************
 * Function : ASCIIToHex(U8 Len) 
 * Description : ��ASCIIת��Ϊ16����          
 * Inputs : none.
 * Outputs : None.
 *��ǰ�汾��1.01
 *���ߣ��ɶ���Ƕ
 *���ʱ�䣺2011��5��08��
 *********************************************************************************************************/
void ASCIIToHex(U8 Len,U8 *WriteStr)
{
	U8 high,low,dat;
	U8 i,j = 0;
	for(i = 0;i < Len;i++)
	{
		if((*(WriteStr + i) != ' ') && (*(WriteStr + i + 1) != ' ')) 
		{
			if((*(WriteStr + i + 1) >= 'a') && (*(WriteStr + i + 1) <= 'f') && \
			   (*(WriteStr + i) >= '0') && (*(WriteStr + i) <= '9')) 
			{
				high = *(WriteStr + i) - 48;        
				low = WriteStr[i + 1] - 87;
				dat = (U8)((high << 4) | low);
				bArray[j] = dat;									
				j++;
				i++;
			}
			else if((*(WriteStr + i) >= 'a') && (*(WriteStr + i) <= 'f') && \
					(*(WriteStr + i + 1) >= '0') && (*(WriteStr + i + 1) <= '9'))
			{
				high = *(WriteStr + i) - 87;
				low = WriteStr[i + 1] - 48;
				dat = (high << 4) | low;
				bArray[j] = (char)dat;
				j++;
				i++;
			}
		
			else if((*(WriteStr + i + 1) >= 'a') && (*(WriteStr + i + 1) <= 'f') && \
					(*(WriteStr + i) >= 'a') && (*(WriteStr + i) <= 'f')) 
			{
				high = *(WriteStr + i) -87;
				low = WriteStr[i + 1] - 87;
				dat = (high << 4) | low;
				bArray[j] = dat;
				j++;
				i++;
			}
			else if((*(WriteStr + i + 1) >= 'A') && (*(WriteStr + i + 1) <= 'F') && \
					(*(WriteStr + i) >= '0') && (*(WriteStr + i) <= '9')) 
			{
				high = *(WriteStr + i) - 48;
				low = WriteStr[i + 1] - 55;
				dat = (char)((high << 4) | low);
				bArray[j] = dat;
				j++;
				i++;
			}
			else if((*(WriteStr + i) >= 'A') && (*(WriteStr + i) <= 'F') && \
					(*(WriteStr + i + 1) >= '0') && (*(WriteStr + i + 1) <= '9')){ 
				high = *(WriteStr + i) - 55;
				low = WriteStr[i + 1] - 48;
				dat = (char)((high << 4) | low);
				bArray[j] = dat;
				j++;
				i++;
			}
			else if((*(WriteStr + i + 1) >= 'A') && (*(WriteStr + i + 1) <= 'F') && \
					(*(WriteStr + i) >= 'A') && (*(WriteStr + i) <= 'F')){ 
				high = *(WriteStr + i) -55;
				low = WriteStr[i + 1] - 55;
				dat = (high << 4) | low;
				bArray[j] = dat;
				j++;
				i++;
			}
			else if((*(WriteStr + i + 1) >= '0') && (*(WriteStr + i + 1) <= '9') && \
					(*(WriteStr + i) >= '0') && (*(WriteStr + i) <= '9'))   
			{
				high = *(WriteStr + i) - 48;
				low = WriteStr[i + 1] - 48;
				dat = (high << 4) | low;
				bArray[j] = dat;
				j++;
				i++;                          
			}						
		}
	}		
}

/********************************************************************************************************
 * Function : void   BSP_I2CISR_Handler   (void) 
 * Description : I2C�жϴ�������           
 * Inputs : None.
 * Outputs : None.
 *��ǰ�汾��0.1
 *���ߣ��ɶ���Ƕ
 *���ʱ�䣺2011��5��10��
**********************************************************************************************************/
void  __irq BSP_I2CISR_Handler   (void)
{
	ClearPending(BIT_IIC);				    
	IIC_Ack = 1;

} 

/********************************************************************************************************
 * Function : void  BSP_I2C_Init(void) 
 * Description : ��ʼ��I2C�ӿ�           
 * Inputs : None.
 * Outputs : None.
 *��ǰ�汾��0.1
 *���ߣ��ɶ���Ƕ
 *���ʱ�䣺2011��5��10��
**********************************************************************************************************/
void BSP_I2C_Init(void)
{
	rGPEUP   = 0xC000;                                 
    rGPECON  = 0xa0000000;                              
	rIICCON  = IICBusAckEn | TxRxIntEn | TransClkVal;	 
//	rIICADD  = 0x10;
	rIICSTAT =	IICDataEn; 						        
	rIICLC   = IICFilterEn | SDAOutDelay5;			     
	pISR_IIC = (U32)BSP_I2CISR_Handler;	                 
	EnableIrq(BIT_IIC);				                    
}