/*************************************************
Function name: ���ǻ���ʵ���һ��ģ��
Parameter    : ��
Description  : ������ʵ�飬ֱ�ӵ��ø�ģ�弴�� ��������ص�ΪMain.c  I2C.h I2C.c ������û�ж���
Return	     : ��
Argument     : ��
Autor & date : Daniel
**************************************************/
#define	GLOBAL_CLK		1
#include <stdlib.h>
#include <string.h>
#include "def.h"
#include "option.h"
#include "2440addr.h"
#include "2440lib.h"
#include "2440slib.h"
#include "mmu.h"
#include "profile.h"
#include "memtest.h"

#include "I2C.h"
												  

/********************************************************************************************************
 * Function : int main(void) 
 * Description : ������          
 * Inputs : none.
 * Outputs : None.
 *��ǰ�汾��1.01
 *���ߣ���ΰ��robert.liao��
 *���ʱ�䣺2011��5��08��
 *********************************************************************************************************/
int Main(void)
{
   U8 WrMemAddr = 0;		 
   U8 WrDatNum  = 0;		
   U8 WrLen = 0;			
   U8 RdMemAddr = 0;		 
   U16 RdDatNum = 0;		
   U8 RdDat[256] = {0};
   U16 i;
   U8 ClearMem[16] = {0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff};
   S8 InputString[6];
   S8 AT24C08_Addr = 0;
   S8 *RdString = "read";
   S8 *WrString = "write";
   S8 *ClrString = "clear";
/*******************************************************/   		
	//BSP_Init();  kangear
	rGPHCON &= ~(0X0F << 4);
	rGPHCON |= (0X0A << 4);	
	PCLK = 50000000;
	Uart_Init(0, 115200);
	Uart_Select(0);  //�����Ǵ��ڳ�ʼ��
	
	MMU_Init();	   //�õ��жϾ�Ҫ��ʼ��mmu
	
	BSP_I2C_Init();	//i2c init	
/********************************************************/


   Uart_Printf("**************************************************************************\n");
   Uart_Printf("		 		�ɶ���Ƕ��Ϣ�������޹�˾			    				\n\n");
   Uart_Printf("			   		I2C��дAT24C08����									\n\n");
   Uart_Printf("Version: V1.00															  \n");
   Uart_Printf("************************************************************************\n\n");
   while(1)
   {
START:  		
		Uart_Printf("Write data input��write   Read data input��read    Clear EEPROM input��clear\n\n");
		Uart_Printf("Select I2C Opreation��");
		Uart_GetString(InputString);        
		Uart_Printf("\n");

		if(!strcmp(WrString,InputString))
		{
			memset(InputString,0,sizeof(InputString));
			memset(WrStr,0,sizeof(WrStr));
			memset(bArray,0,sizeof(bArray));
			WrMemAddr = 0;
			WrDatNum  = 0;
			WrLen     = 0;

	   		Uart_Printf("Input EEPROM Slave Address:");
	   		Uart_GetString((S8 *)WrStr);					
			WrLen = strlen((S8 *)WrStr);					
			ASCIIToHex(WrLen,WrStr);						
			Uart_Printf("\n");
			AT24C08_Addr = bArray[0];

			if((AT24C08_Addr == 0xA0) || (AT24C08_Addr == 0xA2) || \
			   (AT24C08_Addr == 0xA4) || (AT24C08_Addr == 0xA6)){			

		   		Uart_Printf("Input Start Byte  Address:");
		   		WrMemAddr = Uart_GetIntNum_GJ();			    
				Uart_Printf("\n\n");
				

		   		Uart_Printf("Input Write Data number:");
		   		WrDatNum = Uart_GetIntNum_GJ();
				Uart_Printf("\n\n");

				Uart_Printf("Input Write Data:");
				Uart_GetString((S8 *)WrStr);			
				WrLen = strlen((S8 *)WrStr);
				Uart_Printf("\n");
				ASCIIToHex(WrLen,WrStr);

				switch(AT24C08_Addr)
				{
					case 0xA0:
						I2C_Write(0xA0,(WrMemAddr + 0x000),bArray,WrDatNum);
						break;
					case 0xA2:
						I2C_Write(0xA2,(WrMemAddr + 0x100),bArray,WrDatNum);
						break;
					case 0xA4:
						I2C_Write(0xA4,(WrMemAddr + 0x200),bArray,WrDatNum);
						break;
					case 0xA6:
						I2C_Write(0xA6,(WrMemAddr + 0x300),bArray,WrDatNum);
						break;								
				}
				Delay(500);									
				Uart_Printf("write data to AT24C08 End!\n");
				Uart_Printf("************************************************************************\n\n");
			}
			else
			{
			   Uart_Printf("Input EEPROM Slave Address error!\n");
			   goto START;
			}						
		}
		if(!strcmp(RdString,InputString))
		{
			memset(InputString,0,sizeof(InputString));
			memset(WrStr,0,sizeof(WrStr));
			memset(RdDat,0,sizeof(RdDat));
			memset(bArray,0,sizeof(bArray));
			RdMemAddr = 0;
			RdDatNum  = 0;

	   		Uart_Printf("Input EEPROM Slave Address:");
	   		Uart_GetString((S8 *)WrStr);					
			WrLen = strlen((S8 *)WrStr);				
			ASCIIToHex(WrLen,WrStr);					
			Uart_Printf("\n\n");
			AT24C08_Addr = bArray[0];

			if((AT24C08_Addr == 0xA0) || (AT24C08_Addr == 0xA2) || \
			   (AT24C08_Addr == 0xA4) || (AT24C08_Addr == 0xA6)){

		   		Uart_Printf("Input Start Byte Address:");
		   		RdMemAddr = Uart_GetIntNum_GJ();
				Uart_Printf("\n\n");	

		   		Uart_Printf("Input Read Data number:");
		   		RdDatNum = Uart_GetIntNum_GJ();
				Uart_Printf("\n\n");

				switch(AT24C08_Addr)
				{
					case 0xA0:
						I2C_Read(0xA0,(RdMemAddr + 0x000),RdDat,RdDatNum);
						break;
					case 0xA2:
						I2C_Read(0xA2,(RdMemAddr + 0x100),RdDat,RdDatNum);
						break;
					case 0xA4:
						I2C_Read(0xA4,(RdMemAddr + 0x200),RdDat,RdDatNum);
						break;
					case 0xA6:
						I2C_Read(0xA6,(RdMemAddr + 0x300),RdDat,RdDatNum);
						break;								
				}									   
				Uart_Printf("read AT24C08 data is:\n");
				for(i = 0; i < RdDatNum; i++)
				{
					Uart_Printf("0x%x ",RdDat[i]);
				}
				Uart_Printf("\n\n");
				Uart_Printf("Read data from AT24C08 End!\n");
				Uart_Printf("************************************************************************\n\n");
			}
			else
			{
			   Uart_Printf("Input EEPROM Slave Address error!\n");
			   goto START;
			}			
		}
		if(!strcmp(ClrString,InputString))
		{
			memset(InputString,0,sizeof(InputString));
			for(i = 0;i < 16; i++)
			{
				I2C_Write(0xA0,(i * 16),ClearMem,16);	
				Delay(500);									
			}
			for(i = 0;i < 16; i++)						    
			{
				I2C_Write(0xA2,(i * 16) + 0x100,ClearMem,16);
				Delay(500);
			}
			for(i = 0;i < 16; i++)						   
			{
				I2C_Write(0xA4,(i * 16) + 0x200,ClearMem,16);
				Delay(500);
			}
			for(i = 0;i < 16; i++)						   
			{
				I2C_Write(0xA6,(i * 16) + 0x300,ClearMem,16);
				Delay(500);
			}			
			Uart_Printf("clear AT24C08!\n");
			Uart_Printf("************************************************************************\n\n");
		}
			
   }	
}

	


