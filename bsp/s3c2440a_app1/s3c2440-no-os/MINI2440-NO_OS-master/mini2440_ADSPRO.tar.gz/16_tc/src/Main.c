/*************************************************
Function name: ���ǻ���ʵ���һ��ģ��
Parameter    : ��
Description  : ������ʵ�飬ֱ�ӵ��ø�ģ�弴��
Return	     : ��
Argument     : ��
Autor & date : Daniel
**************************************************/
#define	GLOBAL_CLK		1
#include <stdlib.h>
#include <string.h>
#include "def.h"
#include "option.h"
#include "2440addr.h"
#include "2440lib.h"
#include "2440slib.h"
#include "mmu.h"
#include "profile.h"
#include "memtest.h"


#define ADC_FREQ 2500000
//#define ADC_FREQ   1250000

int count = 0;
volatile U32 preScaler;

int xdata,ydata;
void Test_Touchpanel(void);


static void __irq AdcTsAuto(void);


static void cal_cpu_bus_clk(void);
void Set_Clk(void);

/*************************************************
Function name: delay
Parameter    : times
Description	 : ��ʱ����
Return		 : void
Argument     : void
Autor & date : Daniel
**************************************************/
void delay(int times)
{
    int i,j;
    for(i=0;i<times;i++)
       for(j=0;j<400;j++);
}
/*************************************************
Function name: Main
Parameter    : void
Description	 : �����ܺ���
Return		 : void
Argument     : void
Autor & date : Daniel
**************************************************/
int Main(void)
{	
   
    int Scom=0;
    MMU_Init();
    Set_Clk();
    
   	//GPIO int.    
	rGPHCON &= ~(0x0f<<4);
	rGPHCON |= (0x0a<<4);    //TX0 RX0
	
    Uart_Init(0,115200);
    Uart_Select(Scom);
   	Uart_Printf("\nHello World!\n");
    
    Test_Touchpanel();
    
    while(1);
	return 0;

}	

/*************************************************
Function name: Test_Touchpanel
Parameter    : void
Description	 : ��������ʼ��
Return		 : void
Argument     : void
Autor & date : Daniel
**************************************************/
void Test_Touchpanel(void)
{
   
    rADCDLY=50000;                  //Normal conversion mode delay about (1/3.6864M)*50000=13.56ms
    
    /*����ADתƵ��*/
    preScaler = ADC_FREQ;
	Uart_Printf("ADC conv,freq. = %dHz\n",preScaler);
	preScaler = 50000000/ADC_FREQ - 1; //PCLK=50M
	rADCCON = (1<<14)|(preScaler<<6);	//ADCPRS En,PRSCVL
   // rADCCON=(1<<14)+(preScaler<<6);   //ADCPRS En, ADCPRS Value

    Uart_Printf("ADC touch screen test\n");

	/*���ô�����Ϊ�ȴ��ж�ģʽ���ȴ������ʱ�����*/
    rADCTSC=0xd3;  //Wfait,XP_PU,XP_Dis,XM_Dis,YP_Dis,YM_En
    
    /*clear irq*/
    //ClearPending(BIT_ADC);
    rSRCPND = 0x80000000;
	rINTPND = 0x80000000;
    ClearSubPending(BIT_SUB_TC);  
	
	

    pISR_ADC = (U32)AdcTsAuto;


	/*enable INT_TC irq*/
	//EnableIrq(BIT_ADC);
    rINTMSK = 0x7fffffff;	    
    EnableSubIrq(BIT_SUB_TC);
    
}

/*************************************************
Function name: AdcTsAuto
Parameter    : void
Description	 : �жϷ������
Return		 : void
Argument     : void
Autor & date : Daniel
**************************************************/
static void __irq AdcTsAuto(void)
{

	U32	 saveAdcdly;
	
	/****************stylus down************************/
	/*������ж�Դ���ж��Ƿ���INT_TC�жϣ��Ҵ����ʰ���*/
	if(rSUBSRCPND & (BIT_SUB_TC))
	{
		if( !(rADCDAT0&0x8000))
			Uart_Printf("\nStylus down\n");
		else 
		    Uart_Printf("\nStylus up\n");	
	}
	
	/*pull-up disable,�Զ�����X,Y����ת��*/
	rADCTSC = (1<<3)|(1<<2);
	saveAdcdly=rADCDLY;
	rADCDLY=40000;                 //Normal conversion mode delay about (1/50M)*40000=0.8ms
	
	/*��ʼADת��*/
	rADCCON|=0x1;                   //start ADC
    while(rADCCON & 0x1);		//check if Enable_start is low
    
	while(!(rADCCON & 0x8000));  //check if EC(End of Conversion) flag is high, This line is necessary~!!
	
	while(!(rSRCPND & 0x80000000));  //check if ADC is finished with interrupt bit

	/*��ȡX,Y����*/
	xdata=(rADCDAT0&0x3ff);
    ydata=(rADCDAT1&0x3ff);
    
    ClearSubPending(BIT_SUB_TC);
    //ClearPending(BIT_ADC);
    rSRCPND = 0x80000000;
	rINTPND = 0x80000000;  
	

    EnableSubIrq(BIT_SUB_TC);
   	//EnableIrq(BIT_ADC);
    rINTMSK = 0x7fffffff;
    /****************stylus down************************/
    
    
    /****************stylus up**************************/

	/*���ô�����Ϊ�ȴ��ж�ģʽ���ȴ�������̧��*/
    rADCTSC =0xd3;    //Waiting for interrupt
	rADCTSC=rADCTSC|(1<<8); // Detect stylus up interrupt signal.
	
	while(1)		//to check Pen-up state
	{
		if(rSUBSRCPND & (BIT_SUB_TC))	//check if ADC is finished with interrupt bit
		{
					Uart_Printf("Stylus Up Interrupt~!\n");
					break;	//if Stylus is up(1) state
		}
	}	
	/****************stylus up**************************/
	
	Uart_Printf("count=%03d  XP=%04d, YP=%04d\n", count++, xdata, ydata);  
	
	rADCDLY=saveAdcdly; 
	/*���ô�����Ϊ�ȴ��ж�ģʽ���ȴ��´δ����ʰ���*/
    rADCTSC =0xd3;    //Waiting for interrupt
    
	ClearSubPending(BIT_SUB_TC);  
    //ClearPending(BIT_ADC);
    rSRCPND = 0x80000000;
	rINTPND = 0x80000000;

    EnableSubIrq(BIT_SUB_TC);
   	//EnableIrq(BIT_ADC);
    rINTMSK = 0x7fffffff;
}


/*************************************************
Function name: Set_Clk()
Parameter    : void
Description	 : ����CPU��ʱ��Ƶ��
Return		 : void
Argument     : void
Autor & date : Daniel
**************************************************/
void Set_Clk(void)
{
	int i;
	U8 key;
	U32 mpll_val = 0 ;
	i = 2 ;	             //don't use 100M!
		                 //boot_params.cpu_clk.val = 3;
	switch ( i ) {
	case 0:	//200
		key = 12;
		mpll_val = (92<<12)|(4<<4)|(1);
		break;
	case 1:	//300
		key = 13;
		mpll_val = (67<<12)|(1<<4)|(1);
		break;
	case 2:	//400
		key = 14;
		mpll_val = (92<<12)|(1<<4)|(1);
		break;
	case 3:	//440!!!
		key = 14;
		mpll_val = (102<<12)|(1<<4)|(1);
		break;
	default:
		key = 14;
		mpll_val = (92<<12)|(1<<4)|(1);
		break;
	}
	
	//init FCLK=400M, so change MPLL first
	ChangeMPllValue((mpll_val>>12)&0xff, (mpll_val>>4)&0x3f, mpll_val&3);   //set the register--rMPLLCON
	ChangeClockDivider(key, 12);    //the result of rCLKDIVN [0:1:0:1] 3-0 bit
	cal_cpu_bus_clk();    //HCLK=100M   PCLK=50M
}
/*************************************************
Function name: cal_cpu_bus_clk
Parameter    : void
Description	 : ����PCLK\HCLK\FCLK��Ƶ��
Return		 : void
Argument     : void
Autor & date : Daniel
**************************************************/
static void cal_cpu_bus_clk(void)
{
	static U32 cpu_freq;
    static U32 UPLL;
	
	U32 val;
	U8 m, p, s;
	
	val = rMPLLCON;
	m = (val>>12)&0xff;
	p = (val>>4)&0x3f;
	s = val&3;

	//(m+8)*FIN*2 ��Ҫ����32λ��!
	FCLK = ((m+8)*(FIN/100)*2)/((p+2)*(1<<s))*100;     //FCLK=400M  FIN=12000000
	
	val = rCLKDIVN;
	m = (val>>1)&3;
	p = val&1;	
	val = rCAMDIVN;
	s = val>>8;
	
	switch (m) {
	case 0:
		HCLK = FCLK;
		break;
	case 1:
		HCLK = FCLK>>1;
		break;
	case 2:
		if(s&2)
			HCLK = FCLK>>3;
		else
			HCLK = FCLK>>2;
		break;
	case 3:
		if(s&1)
			HCLK = FCLK/6;
		else
			HCLK = FCLK/3;
		break;
	}
	
	if(p)
		PCLK = HCLK>>1;
	else
		PCLK = HCLK;
	
	if(s&0x10)
		cpu_freq = HCLK;
	else
		cpu_freq = FCLK;
		
	val = rUPLLCON;
	m = (val>>12)&0xff;
	p = (val>>4)&0x3f;
	s = val&3;
	UPLL = ((m+8)*FIN)/((p+2)*(1<<s));
	UCLK = (rCLKDIVN&8)?(UPLL>>1):UPLL;
}


