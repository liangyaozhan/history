/*********************************************************************************************************
*
*                                        GQ2440 NandFlash��������
*
*                                            SAMSUNG S3C2440 
*                                                 on the
*                                        GQ2440 Evaluation Board
*
* Filename      : NandFlash.h
* Version       : V1.00
* Programmer(s) : Robert.liao
* LegalCopyright: �ɶ���Ƕ��Ϣ�������޹�˾
*********************************************************************************************************/
#ifndef __NANDFLASH_H__
#define __NANDFLASH_H__


#define DEBUGFLASH									 //ʹ�ܴ��ڴ�ӡ
#define DEBUGECC									 //ʹ��ECC����У��
//-----------------------------------------------------------------------------------------------------
//���üĴ���NFCONF����
//-----------------------------------------------------------------------------------------------------
#define TACLS										(0x01 << 12)

#define TWRPH0										(0x02 << 8)

#define TWRPH1										(0x00 << 4)

#define AdvanceFlash								(0x01 << 3)
#define NormalFlash									(0x00 << 3)
//PageSize
#define PageSize256N								(0x00 << 2)	//��AdvanceFlash=0ʱ
#define PageSize512N								(0x01 << 2)	//��AdvanceFlash=0ʱ
#define PageSize1024A								(0x00 << 2)  //��AdvanceFlash=1ʱ
#define PageSize2048A								(0x01 << 2)   //��AdvanceFlash=1ʱ

#define AddrCycle3N									(0x00 << 1)	//��AdvanceFlash=0ʱ
#define AddrCycle4N									(0x01 << 1)	//��AdvanceFlash=0ʱ
#define AddrCycle4A									(0x00 << 1)	//��AdvanceFlash=1ʱ
#define AddrCycle5A									(0x01 << 1)	//��AdvanceFlash=1ʱ

#define BusWidth8									(0x00 << 0)
#define BusWidth16									(0x01 << 0)

//----------------------------------------------------------------------------------------------------- 
//���ƼĴ���NFCONT���� 
//----------------------------------------------------------------------------------------------------- 
#define	Dis_Locktight							   ~(0x01 << 13)
#define En_Locktight								(0x01 << 13)

#define Dis_SoftLock							   ~(0x01 << 12)
#define En_SoftLock									(0x01 << 12)

#define Dis_LegalInt							   ~(0x01 << 10)
#define En_LegalInt									(0x01 << 10)

#define Dis_RnBInt								   ~(0x01 << 9)
#define En_RnBInt									(0x01 << 9)

#define RnBTrans_rising							   ~(0x01 << 8)
#define RnBTrans_falling							(0x01 << 8)

#define UnlockspareECC							   ~(0x01 << 6)
#define LockspareECC								(0x01 << 6)

#define UnlockmainECC							   ~(0x01 << 5)
#define LockmainECC									(0x01 << 5)

#define InitECC										(0x01 << 4)

#define	EnChipSel								   ~(0x01 << 1)
#define DisChipSel									(0x01 << 1)

#define DisFlashCntl							   ~(0x01 << 0)
#define EnFlashCntl									(0x01 << 0)								

//----------------------------------------------------------------------------------------------------- 
//״̬�Ĵ���NFSTAT���� 
//----------------------------------------------------------------------------------------------------- 
#define IllegalAccessNoDetect					   ~(0x01 << 3)
#define IllegalAccessDetect							(0x01 << 3)
													
#define RnBTransNoDetect						   ~(0x01 << 2)	
#define RnBTransDetect								(0x01 << 2)	

#define ReadnCE										(0x01 << 1)

#define FlashBusy								   ~(0x01 << 0)
#define FlashReady									(0x01 << 0)
 


//-----------------------------------------------------------------------------------------------------
// ECC0/1״̬�Ĵ���
//-----------------------------------------------------------------------------------------------------
#define SpareNoError								(0x00 << 2)
#define SpareOneError								(0x01 << 2)
#define SpareMultError								(0x02 << 2)
#define SpareAreaError								(0x03 << 2)

#define MainNoError									(0x00 << 0)								 
#define MainOneError								(0x01 << 0)
#define MainMultError								(0x02 << 0)
#define MainAreaError								(0x03 << 0)


//-----------------------------------------------------------------------------------------------------
// NAND Flash ����
//-----------------------------------------------------------------------------------------------------
#define NAND_CMD_READ0         						0x00         // Read mode (1) command
#define NAND_CMD_READ1         						0x01         // Read mode (2) command
#define NAND_CMD_RandomREAD0					    0x05		 // RandomRead mode (1) command
#define NAND_CMD_RandomREAD1						0xE0		 // RandomRead mode (2) command

#define NAND_CMD_RandomWrite0						0x85		 //RandomWrite mode (1) command

#define NAND_CMD_PAGEPROG      						0x10         // Auto program command
#define NAND_CMD_READSTART     						0x30         // Read start command
#define NAND_CMD_READ2         						0x50         // Read mode (3) command
#define NAND_CMD_ERASE1ST      						0x60         // Auto block erase 1-st command
#define NAND_CMD_STATUS        						0x70         // Status read (1) command
#define NAND_CMD_STATUS_MULTI  						0x71         // Status read (2) command
#define NAND_CMD_SDIN          						0x80         // Serial data input command
#define NAND_CMD_READID        						0x90         // ID read (1) command
#define NAND_CMD_ERASE2ND      						0xD0         // Auto block erase 2-nd command
#define NAND_CMD_RESET         						0xFF         // Reset command


#define NF_Sel_Chip()								rNFCONT &= EnChipSel			  		//CEΪ�ͣ�ѡ��оƬ
#define NF_DisSel_Chip()							rNFCONT |= DisChipSel				    //����CE��ȡ��оƬѡ��

#define EraseSucess									0x01
#define EraseUnSucess								0x02

#define MarkBadBlockSucess							0x03
#define MarkBadBlockUnSucess						0x04					

extern 	U8 OnePage[2048];
//-----------------------------------------------------------------------------------------------------
// ��������
//-----------------------------------------------------------------------------------------------------
void 	NF_Detect_Busy								(void);
U8 	NF_Read_Status								(void);
int 	InitFlashController_HW 						(void); 
void 	NandFlash_GetId								(void);
void 	NandFlash_Read_Page							(U32 PageAddr);
void 	ECC_Error									(void);
U8 	NF_Check_BadBlock							(U32 PageAddr,U32 ECC_Addr);
U8 	NF_Mark_BadBlock							(U32 PageAddr,U32 ECC_Addr,U8 MarkBadBlock);
U8 	NandFlash_Program_Page						(U32 Addr);
U8 	NandFlash_Block_Erase						(U32 PageAddr);
#endif














