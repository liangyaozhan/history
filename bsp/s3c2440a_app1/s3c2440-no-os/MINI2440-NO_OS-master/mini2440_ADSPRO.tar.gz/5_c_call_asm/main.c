//main.c
#include <stdio.h>

extern int asmSum1(int src, int dest,int* san);

int Main()
{
	int s = 2;
	int d = 3;
	int psum[1];
	int c = (int)psum;
	asmSum1(s, d, psum);
	//see c
	return 0;
}
